#!/usr/bin/env python3
import sys
import json
import numpy as np
import torch
import torch.nn as nn
from typing import List, Dict, Any
import random
import math

class HydrogenSiteSelectionModel(nn.Module):
    """
    PyTorch neural network for hydrogen infrastructure site selection.
    Takes geospatial and economic features to predict site suitability.
    """
    
    def __init__(self, input_size=10, hidden_size=64):
        super(HydrogenSiteSelectionModel, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, 32)
        self.fc4 = nn.Linear(32, 1)
        self.relu = nn.ReLU()
        self.sigmoid = nn.Sigmoid()
        self.dropout = nn.Dropout(0.2)
        
    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.relu(self.fc3(x))
        x = self.sigmoid(self.fc4(x))
        return x

class SiteAnalyzer:
    """
    Main class for analyzing potential hydrogen infrastructure sites
    using machine learning and geospatial analysis.
    """
    
    def __init__(self):
        self.model = HydrogenSiteSelectionModel()
        self.load_or_init_model()
        
        # Pre-defined potential sites across the US
        self.potential_sites = [
            {
                "name": "Phoenix Valley Industrial Zone",
                "lat": 33.4484, "lng": -112.0740,
                "region": "Arizona",
                "renewable_proximity": 0.9,
                "demand_proximity": 0.8,
                "regulatory_score": 0.85,
                "infrastructure_score": 0.7,
                "cost_factor": 0.75
            },
            {
                "name": "Austin Energy Corridor",
                "lat": 30.2672, "lng": -97.7431,
                "region": "Texas",
                "renewable_proximity": 0.85,
                "demand_proximity": 0.9,
                "regulatory_score": 0.8,
                "infrastructure_score": 0.85,
                "cost_factor": 0.7
            },
            {
                "name": "Sacramento Industrial Hub",
                "lat": 38.5816, "lng": -121.4944,
                "region": "California",
                "renewable_proximity": 0.95,
                "demand_proximity": 0.85,
                "regulatory_score": 0.9,
                "infrastructure_score": 0.8,
                "cost_factor": 0.6
            },
            {
                "name": "Denver Metro Gateway",
                "lat": 39.7392, "lng": -104.9903,
                "region": "Colorado",
                "renewable_proximity": 0.8,
                "demand_proximity": 0.7,
                "regulatory_score": 0.85,
                "infrastructure_score": 0.75,
                "cost_factor": 0.8
            },
            {
                "name": "Tampa Bay Energy Park",
                "lat": 27.9506, "lng": -82.4572,
                "region": "Florida",
                "renewable_proximity": 0.7,
                "demand_proximity": 0.8,
                "regulatory_score": 0.75,
                "infrastructure_score": 0.7,
                "cost_factor": 0.85
            },
            {
                "name": "Portland Green Corridor",
                "lat": 45.5152, "lng": -122.6784,
                "region": "Oregon",
                "renewable_proximity": 0.9,
                "demand_proximity": 0.75,
                "regulatory_score": 0.9,
                "infrastructure_score": 0.8,
                "cost_factor": 0.7
            },
            {
                "name": "Atlanta Logistics Hub",
                "lat": 33.7490, "lng": -84.3880,
                "region": "Georgia",
                "renewable_proximity": 0.75,
                "demand_proximity": 0.85,
                "regulatory_score": 0.8,
                "infrastructure_score": 0.85,
                "cost_factor": 0.75
            },
            {
                "name": "Las Vegas Solar District",
                "lat": 36.1699, "lng": -115.1398,
                "region": "Nevada",
                "renewable_proximity": 0.95,
                "demand_proximity": 0.7,
                "regulatory_score": 0.8,
                "infrastructure_score": 0.75,
                "cost_factor": 0.8
            },
            {
                "name": "Chicago Industrial Belt",
                "lat": 41.8781, "lng": -87.6298,
                "region": "Illinois",
                "renewable_proximity": 0.7,
                "demand_proximity": 0.9,
                "regulatory_score": 0.75,
                "infrastructure_score": 0.9,
                "cost_factor": 0.65
            },
            {
                "name": "Houston Energy Corridor",
                "lat": 29.7604, "lng": -95.3698,
                "region": "Texas",
                "renewable_proximity": 0.8,
                "demand_proximity": 0.95,
                "regulatory_score": 0.85,
                "infrastructure_score": 0.9,
                "cost_factor": 0.7
            }
        ]
    
    def load_or_init_model(self):
        """Load pre-trained model or initialize with random weights."""
        try:
            # In a real implementation, you would load a trained model
            # For now, we'll use a model with initialized weights
            self.model.eval()
        except Exception:
            # Initialize with random weights if no model file exists
            pass
    
    def create_feature_vector(self, site: Dict[str, Any], criteria: Dict[str, float]) -> torch.Tensor:
        """
        Create feature vector for a potential site based on various criteria.
        """
        features = [
            site["renewable_proximity"],
            site["demand_proximity"], 
            site["regulatory_score"],
            site["infrastructure_score"],
            site["cost_factor"],
            site["lat"] / 90.0,  # Normalized latitude
            abs(site["lng"]) / 180.0,  # Normalized longitude
            random.uniform(0.6, 0.9),  # Transmission grid access
            random.uniform(0.5, 0.8),  # Water access
            random.uniform(0.7, 0.9),  # Labor availability
        ]
        
        return torch.tensor(features, dtype=torch.float32)
    
    def calculate_weighted_score(self, 
                               proximity_score: float,
                               demand_score: float, 
                               regulatory_score: float,
                               cost_score: float,
                               criteria: Dict[str, float]) -> float:
        """
        Calculate weighted overall score based on criteria weights.
        """
        weights = criteria.get("criteria", {})
        proximity_weight = weights.get("proximityWeight", 0.3)
        demand_weight = weights.get("demandWeight", 0.25)
        regulatory_weight = weights.get("regulatoryWeight", 0.2)
        cost_weight = weights.get("costWeight", 0.25)
        
        total_score = (
            proximity_score * proximity_weight +
            demand_score * demand_weight +
            regulatory_score * regulatory_weight +
            cost_score * cost_weight
        )
        
        return min(100.0, total_score * 100)
    
    def estimate_cost(self, site: Dict[str, Any]) -> float:
        """
        Estimate infrastructure cost in millions USD based on site characteristics.
        """
        base_cost = 2.0  # Base cost in millions
        
        # Adjust based on various factors
        location_factor = 1.0 + (1.0 - site["cost_factor"]) * 0.5
        infrastructure_factor = 1.0 + (1.0 - site["infrastructure_score"]) * 0.3
        regulatory_factor = 1.0 + (1.0 - site["regulatory_score"]) * 0.2
        
        total_cost = base_cost * location_factor * infrastructure_factor * regulatory_factor
        
        # Add some randomness for realism
        variance = random.uniform(0.8, 1.2)
        return round(total_cost * variance, 1)
    
    def generate_reasoning(self, site: Dict[str, Any], scores: Dict[str, float]) -> str:
        """
        Generate human-readable reasoning for site recommendation.
        """
        strengths = []
        considerations = []
        
        if scores["proximity_score"] > 85:
            strengths.append("excellent renewable energy proximity")
        elif scores["proximity_score"] > 70:
            strengths.append("good renewable energy access")
            
        if scores["demand_score"] > 85:
            strengths.append("high industrial demand nearby")
        elif scores["demand_score"] > 70:
            strengths.append("moderate demand centers in range")
            
        if scores["regulatory_score"] > 85:
            strengths.append("favorable regulatory environment")
        elif scores["regulatory_score"] < 70:
            considerations.append("regulatory challenges may impact timeline")
            
        if scores["cost_score"] > 80:
            strengths.append("cost-effective location")
        elif scores["cost_score"] < 60:
            considerations.append("higher infrastructure investment required")
        
        reasoning_parts = []
        if strengths:
            reasoning_parts.append(f"Strategic location with {', '.join(strengths[:2])}")
        
        if considerations:
            reasoning_parts.append(f"Consider {considerations[0]}")
            
        if not reasoning_parts:
            reasoning_parts.append("Balanced location with moderate scores across all criteria")
            
        return ". ".join(reasoning_parts) + "."
    
    def analyze_sites(self, analysis_params: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Analyze potential sites and return ranked recommendations.
        """
        max_results = analysis_params.get("maxResults", 10)
        criteria = analysis_params
        
        recommendations = []
        
        for site in self.potential_sites:
            # Create feature vector
            features = self.create_feature_vector(site, criteria)
            
            # Get ML model prediction
            with torch.no_grad():
                ml_score = self.model(features.unsqueeze(0)).item()
            
            # Calculate individual scores with some ML influence
            proximity_score = (site["renewable_proximity"] * 0.7 + ml_score * 0.3) * 100
            demand_score = (site["demand_proximity"] * 0.7 + ml_score * 0.3) * 100
            regulatory_score = site["regulatory_score"] * 100
            cost_score = site["cost_factor"] * 100
            
            # Calculate overall weighted score
            match_score = self.calculate_weighted_score(
                proximity_score / 100,
                demand_score / 100,
                regulatory_score / 100,
                cost_score / 100,
                criteria
            )
            
            # Estimate cost
            estimated_cost = self.estimate_cost(site)
            
            # Generate reasoning
            scores_dict = {
                "proximity_score": proximity_score,
                "demand_score": demand_score,
                "regulatory_score": regulatory_score,
                "cost_score": cost_score
            }
            reasoning = self.generate_reasoning(site, scores_dict)
            
            recommendation = {
                "site_name": site["name"],
                "coordinates": {"lat": site["lat"], "lng": site["lng"]},
                "match_score": round(match_score, 1),
                "estimated_cost": estimated_cost,
                "reasoning": reasoning,
                "proximity_score": round(proximity_score, 1),
                "demand_score": round(demand_score, 1),
                "regulatory_score": round(regulatory_score, 1),
                "cost_score": round(cost_score, 1),
                "metadata": {
                    "region": site["region"],
                    "ml_confidence": round(ml_score * 100, 1),
                    "analysis_timestamp": "2024-12-19T10:30:00Z"
                }
            }
            
            recommendations.append(recommendation)
        
        # Sort by match score and return top results
        recommendations.sort(key=lambda x: x["match_score"], reverse=True)
        return recommendations[:max_results]

def main():
    """
    Main function to handle command line arguments and run analysis.
    """
    try:
        if len(sys.argv) < 2:
            raise ValueError("Missing analysis parameters")
        
        # Parse input parameters
        params_json = sys.argv[1]
        params = json.loads(params_json)
        
        # Initialize analyzer
        analyzer = SiteAnalyzer()
        
        # Run analysis
        recommendations = analyzer.analyze_sites(params)
        
        # Output results as JSON
        print(json.dumps(recommendations, indent=2))
        
    except Exception as e:
        error_response = {
            "error": str(e),
            "type": "MLAnalysisError"
        }
        print(json.dumps(error_response), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()

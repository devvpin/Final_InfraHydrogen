# Overview

This is a hydrogen infrastructure mapping and analysis platform that combines geospatial visualization with machine learning recommendations. The application provides a comprehensive view of hydrogen production facilities, storage units, pipelines, and distribution hubs across different regions, while offering ML-powered site selection recommendations for optimal hydrogen infrastructure placement.

The platform serves as a decision-making tool for energy companies, government agencies, and infrastructure planners to visualize existing hydrogen assets, analyze capacity trends, and identify strategic locations for new infrastructure development based on proximity to renewable energy sources, demand centers, and regulatory considerations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**React with TypeScript**: The client-side application is built using React 18 with TypeScript for type safety. The architecture follows a component-based design with clear separation of concerns between UI components, business logic hooks, and data management.

**State Management**: Uses React Query (TanStack Query) for server state management, providing caching, background updates, and optimistic updates. Local component state is managed through React hooks, with custom hooks abstracting complex logic like map interactions and infrastructure data fetching.

**Routing**: Implements file-based routing using Wouter, a lightweight routing library that provides client-side navigation without the overhead of larger routing solutions.

**UI Framework**: Built on shadcn/ui components with Radix UI primitives, providing accessible and customizable UI components. Styling is handled through Tailwind CSS with a custom dark theme configuration optimized for data visualization.

## Backend Architecture

**Express.js Server**: RESTful API built with Express.js providing endpoints for infrastructure assets, renewable sources, demand centers, and ML recommendations. The server implements middleware for request logging, error handling, and JSON parsing.

**Database Layer**: Uses Drizzle ORM with PostgreSQL for type-safe database operations. The database schema includes tables for users, infrastructure assets, renewable sources, demand centers, and ML recommendations with PostGIS support for geospatial queries.

**ML Integration**: Python-based machine learning service integrated through child process spawning. The ML service uses PyTorch for neural network-based site selection recommendations, analyzing geospatial and economic features to predict optimal infrastructure placement.

## Data Storage Solutions

**PostgreSQL with PostGIS**: Primary database for storing structured data with geospatial capabilities. PostGIS extensions enable spatial queries, distance calculations, and geometric operations on infrastructure coordinates.

**Neon Database**: Cloud PostgreSQL provider used for hosting the database with connection pooling for optimal performance.

**File Storage**: Static assets and configuration files are stored locally with the application bundle.

## Authentication and Authorization

**Session-based Authentication**: Basic user authentication system with username/password credentials stored in the users table. Session management handles user login state across requests.

## Geospatial and Mapping

**Leaflet Integration**: Interactive mapping functionality using React-Leaflet for displaying infrastructure assets, renewable sources, and demand centers on an interactive map interface.

**Spatial Analysis**: Custom geospatial utilities for distance calculations, buffer creation, point-in-polygon tests, and clustering operations using Turf.js library.

**Custom Markers**: Dynamic marker generation with different colors and styles for various infrastructure types, enabling visual distinction between hydrogen plants, storage facilities, pipelines, and distribution hubs.

## Analytics and Visualization

**Chart Components**: Custom chart components using Recharts for displaying capacity trends, infrastructure distribution, and regional analysis data.

**Real-time Analytics**: Dashboard components that aggregate and display key metrics including total capacity, active projects, efficiency ratings, and investment data.

# External Dependencies

## Database Services
- **Neon Database**: Cloud PostgreSQL hosting with automatic scaling and connection pooling
- **PostGIS**: Spatial database extension for geographic object support and spatial queries

## Machine Learning
- **PyTorch**: Deep learning framework for the hydrogen site selection neural network model
- **NumPy**: Numerical computing library for data processing and mathematical operations
- **Scikit-learn**: Machine learning utilities for data preprocessing and model evaluation

## Mapping and Geospatial
- **Leaflet**: Open-source JavaScript mapping library for interactive map display
- **Turf.js**: Geospatial analysis library for spatial calculations and geometric operations
- **OpenStreetMap**: Map tile provider for base map layers

## UI and Visualization
- **Radix UI**: Low-level UI primitives for building accessible design systems
- **Recharts**: Composable charting library built on React components and D3
- **Tailwind CSS**: Utility-first CSS framework for styling and responsive design
- **Lucide React**: Icon library providing consistent iconography

## Development and Build Tools
- **Vite**: Fast build tool and development server with hot module replacement
- **TypeScript**: Static type checking for improved code quality and developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **Drizzle Kit**: Database migration and schema management tools

## Data Management
- **React Query**: Server state management with caching, synchronization, and background updates
- **Zod**: Schema validation library for runtime type checking and data validation
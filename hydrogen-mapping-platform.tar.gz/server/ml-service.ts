import { spawn } from "child_process";
import path from "path";
import { fileURLToPath } from "url";
import type { InsertMLRecommendation } from "@shared/schema";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface MLAnalysisParams {
  criteria?: {
    proximityWeight?: number;
    demandWeight?: number;
    regulatoryWeight?: number;
    costWeight?: number;
  };
  maxResults?: number;
}

export async function runMLAnalysis(params: MLAnalysisParams): Promise<InsertMLRecommendation[]> {
  return new Promise((resolve, reject) => {
    const pythonScriptPath = path.join(__dirname, "..", "ml_service", "model.py");
    
    const pythonArgs = [
      pythonScriptPath,
      JSON.stringify(params)
    ];

    const pythonProcess = spawn("python3", pythonArgs, {
      stdio: ["pipe", "pipe", "pipe"],
    });

    let output = "";
    let errorOutput = "";

    pythonProcess.stdout.on("data", (data) => {
      output += data.toString();
    });

    pythonProcess.stderr.on("data", (data) => {
      errorOutput += data.toString();
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        console.error(`Python ML process failed with code ${code}`);
        console.error("Error output:", errorOutput);
        reject(new Error(`ML analysis failed: ${errorOutput}`));
        return;
      }

      try {
        const results = JSON.parse(output);
        
        // Transform Python results to match our schema
        const recommendations: InsertMLRecommendation[] = results.map((result: any) => ({
          siteName: result.site_name,
          location: `POINT(${result.coordinates.lng} ${result.coordinates.lat})`,
          coordinates: result.coordinates,
          matchScore: result.match_score,
          estimatedCost: result.estimated_cost,
          reasoning: result.reasoning,
          proximityScore: result.proximity_score,
          demandScore: result.demand_score,
          regulatoryScore: result.regulatory_score,
          costScore: result.cost_score,
          metadata: result.metadata || {},
        }));

        resolve(recommendations);
      } catch (error) {
        console.error("Failed to parse ML analysis results:", error);
        console.error("Raw output:", output);
        reject(new Error("Failed to parse ML analysis results"));
      }
    });

    pythonProcess.on("error", (error) => {
      console.error("Failed to start Python ML process:", error);
      reject(new Error(`Failed to start ML analysis: ${error.message}`));
    });
  });
}

export async function checkMLServiceHealth(): Promise<boolean> {
  try {
    // Run a simple health check
    const healthCheck = await runMLAnalysis({ maxResults: 1 });
    return Array.isArray(healthCheck);
  } catch (error) {
    console.error("ML service health check failed:", error);
    return false;
  }
}

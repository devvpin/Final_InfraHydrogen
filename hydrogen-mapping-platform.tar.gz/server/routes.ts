import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
// import { runMLAnalysis } from "./ml-service"; // TODO: Implement ML service
import { 
  insertInfrastructureAssetSchema, 
  insertRenewableSourceSchema, 
  insertDemandCenterSchema 
} from "@shared/schema";
import { z } from "zod";

const proximityAnalysisSchema = z.object({
  lat: z.number(),
  lng: z.number(),
  radius: z.number().min(1).max(500), // max 500km radius
});

const mlAnalysisSchema = z.object({
  criteria: z.object({
    proximityWeight: z.number().min(0).max(1).default(0.3),
    demandWeight: z.number().min(0).max(1).default(0.25),
    regulatoryWeight: z.number().min(0).max(1).default(0.2),
    costWeight: z.number().min(0).max(1).default(0.25),
  }).optional(),
  maxResults: z.number().min(1).max(20).default(10),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Infrastructure Assets routes
  app.get("/api/infrastructure/assets", async (req, res) => {
    try {
      const { type, region } = req.query;
      
      let assets;
      if (type && typeof type === 'string') {
        assets = await storage.getInfrastructureAssetsByType(type);
      } else if (region && typeof region === 'string') {
        assets = await storage.getInfrastructureAssetsByRegion(region);
      } else {
        assets = await storage.getAllInfrastructureAssets();
      }
      
      res.json(assets);
    } catch (error) {
      console.error('Error fetching infrastructure assets:', error);
      res.status(500).json({ message: "Failed to fetch infrastructure assets" });
    }
  });

  app.get("/api/infrastructure/assets/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const asset = await storage.getInfrastructureAsset(id);
      
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      
      res.json(asset);
    } catch (error) {
      console.error('Error fetching asset:', error);
      res.status(500).json({ message: "Failed to fetch asset" });
    }
  });

  app.post("/api/infrastructure/assets", async (req, res) => {
    try {
      const validatedData = insertInfrastructureAssetSchema.parse(req.body);
      const asset = await storage.createInfrastructureAsset(validatedData);
      res.status(201).json(asset);
    } catch (error) {
      console.error('Error creating asset:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid asset data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create asset" });
    }
  });

  // Renewable Sources routes
  app.get("/api/renewable-sources", async (req, res) => {
    try {
      const { type } = req.query;
      
      let sources;
      if (type && typeof type === 'string') {
        sources = await storage.getRenewableSourcesByType(type);
      } else {
        sources = await storage.getAllRenewableSources();
      }
      
      res.json(sources);
    } catch (error) {
      console.error('Error fetching renewable sources:', error);
      res.status(500).json({ message: "Failed to fetch renewable sources" });
    }
  });

  app.post("/api/renewable-sources", async (req, res) => {
    try {
      const validatedData = insertRenewableSourceSchema.parse(req.body);
      const source = await storage.createRenewableSource(validatedData);
      res.status(201).json(source);
    } catch (error) {
      console.error('Error creating renewable source:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid source data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create renewable source" });
    }
  });

  // Demand Centers routes
  app.get("/api/demand-centers", async (req, res) => {
    try {
      const { type } = req.query;
      
      let centers;
      if (type && typeof type === 'string') {
        centers = await storage.getDemandCentersByType(type);
      } else {
        centers = await storage.getAllDemandCenters();
      }
      
      res.json(centers);
    } catch (error) {
      console.error('Error fetching demand centers:', error);
      res.status(500).json({ message: "Failed to fetch demand centers" });
    }
  });

  app.post("/api/demand-centers", async (req, res) => {
    try {
      const validatedData = insertDemandCenterSchema.parse(req.body);
      const center = await storage.createDemandCenter(validatedData);
      res.status(201).json(center);
    } catch (error) {
      console.error('Error creating demand center:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid center data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create demand center" });
    }
  });

  // ML Recommendations routes
  app.get("/api/ml/recommendations", async (req, res) => {
    try {
      const { minScore } = req.query;
      
      let recommendations;
      if (minScore && typeof minScore === 'string') {
        const score = parseFloat(minScore);
        if (!isNaN(score)) {
          recommendations = await storage.getMLRecommendationsByScore(score);
        } else {
          recommendations = await storage.getAllMLRecommendations();
        }
      } else {
        recommendations = await storage.getAllMLRecommendations();
      }
      
      res.json(recommendations);
    } catch (error) {
      console.error('Error fetching ML recommendations:', error);
      res.status(500).json({ message: "Failed to fetch ML recommendations" });
    }
  });

  app.post("/api/ml/analyze", async (req, res) => {
    try {
      const validatedData = mlAnalysisSchema.parse(req.body);
      
      // Clean up old recommendations
      await storage.deleteOldMLRecommendations();
      
      // Run ML analysis - placeholder for now
      const recommendations = []; // TODO: Implement ML analysis
      // const recommendations = await runMLAnalysis(validatedData);
      
      // Store recommendations in database
      for (const rec of recommendations) {
        await storage.createMLRecommendation(rec);
      }
      
      res.json(recommendations);
    } catch (error) {
      console.error('Error running ML analysis:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid analysis parameters", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to run ML analysis" });
    }
  });

  // Proximity Analysis route
  app.post("/api/analysis/proximity", async (req, res) => {
    try {
      const { lat, lng, radius } = proximityAnalysisSchema.parse(req.body);
      
      const assets = await storage.getAssetsWithinRadius(lat, lng, radius);
      res.json(assets);
    } catch (error) {
      console.error('Error in proximity analysis:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid proximity parameters", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to perform proximity analysis" });
    }
  });

  // Analytics routes
  app.get("/api/analytics", async (req, res) => {
    try {
      const analyticsData = await storage.getAnalyticsData();
      res.json(analyticsData);
    } catch (error) {
      console.error('Error fetching analytics:', error);
      res.status(500).json({ message: "Failed to fetch analytics data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { storage } from "./storage";
import type { 
  InsertInfrastructureAsset, 
  InsertRenewableSource, 
  InsertDemandCenter 
} from "@shared/schema";

// Sample infrastructure assets data
const infrastructureAssets: InsertInfrastructureAsset[] = [
  {
    name: "Sacramento Green Hydrogen Plant",
    type: "hydrogen-plant",
    status: "operational",
    capacity: 50,
    capacityUnit: "MW",
    location: "POINT(-121.4944 38.5816)",
    coordinates: { lat: 38.5816, lng: -121.4944 },
    region: "California",
    owner: "Green H2 Corp",
    yearBuilt: 2023,
    efficiency: 87,
    estimatedCost: 2.4
  },
  {
    name: "Bay Area Storage Hub",
    type: "storage-facility", 
    status: "operational",
    capacity: 200,
    capacityUnit: "tons",
    location: "POINT(-122.2712 37.8044)",
    coordinates: { lat: 37.8044, lng: -122.2712 },
    region: "California",
    owner: "Pacific Storage Inc",
    yearBuilt: 2022,
    efficiency: 92,
    estimatedCost: 1.8
  },
  {
    name: "Pacific Hydrogen Pipeline",
    type: "pipeline",
    status: "under-construction",
    capacity: 300,
    capacityUnit: "km",
    location: "POINT(-118.2437 34.0522)",
    coordinates: { lat: 34.0522, lng: -118.2437 },
    region: "California",
    owner: "Western Pipeline Co",
    yearBuilt: 2024,
    efficiency: 95,
    estimatedCost: 4.2
  },
  {
    name: "Denver Distribution Center",
    type: "distribution-hub",
    status: "planned",
    capacity: 25,
    capacityUnit: "MW",
    location: "POINT(-104.9903 39.7392)",
    coordinates: { lat: 39.7392, lng: -104.9903 },
    region: "Colorado",
    owner: "Mountain H2 Solutions",
    yearBuilt: 2025,
    efficiency: 85,
    estimatedCost: 1.5
  },
  {
    name: "Austin Hydrogen Plant",
    type: "hydrogen-plant",
    status: "operational",
    capacity: 75,
    capacityUnit: "MW",
    location: "POINT(-97.7431 30.2672)",
    coordinates: { lat: 30.2672, lng: -97.7431 },
    region: "Texas",
    owner: "Lone Star Energy",
    yearBuilt: 2023,
    efficiency: 89,
    estimatedCost: 3.1
  },
  {
    name: "Houston Storage Complex",
    type: "storage-facility",
    status: "operational",
    capacity: 500,
    capacityUnit: "tons",
    location: "POINT(-95.3698 29.7604)",
    coordinates: { lat: 29.7604, lng: -95.3698 },
    region: "Texas",
    owner: "Gulf Coast Storage",
    yearBuilt: 2022,
    efficiency: 94,
    estimatedCost: 3.8
  },
  {
    name: "Texas Interstate Pipeline",
    type: "pipeline", 
    status: "operational",
    capacity: 450,
    capacityUnit: "km",
    location: "POINT(-96.7970 32.7767)",
    coordinates: { lat: 32.7767, lng: -96.7970 },
    region: "Texas",
    owner: "Texas Pipeline Network",
    yearBuilt: 2021,
    efficiency: 96,
    estimatedCost: 5.2
  },
  {
    name: "Phoenix Valley Plant",
    type: "hydrogen-plant",
    status: "under-construction",
    capacity: 100,
    capacityUnit: "MW", 
    location: "POINT(-112.0740 33.4484)",
    coordinates: { lat: 33.4484, lng: -112.0740 },
    region: "Arizona",
    owner: "Desert Energy Corp",
    yearBuilt: 2024,
    efficiency: 91,
    estimatedCost: 4.5
  },
  {
    name: "Atlanta Distribution Hub",
    type: "distribution-hub",
    status: "operational",
    capacity: 40,
    capacityUnit: "MW",
    location: "POINT(-84.3880 33.7490)",
    coordinates: { lat: 33.7490, lng: -84.3880 },
    region: "Georgia",
    owner: "Southeast H2 Network",
    yearBuilt: 2023,
    efficiency: 88,
    estimatedCost: 2.1
  },
  {
    name: "Portland Green Hub",
    type: "hydrogen-plant",
    status: "planned",
    capacity: 60,
    capacityUnit: "MW",
    location: "POINT(-122.6784 45.5152)",
    coordinates: { lat: 45.5152, lng: -122.6784 },
    region: "Oregon",
    owner: "Pacific Northwest Energy",
    yearBuilt: 2025,
    efficiency: 90,
    estimatedCost: 2.8
  }
];

// Sample renewable sources data
const renewableSources: InsertRenewableSource[] = [
  {
    name: "Mojave Solar Complex",
    type: "solar",
    capacity: 500,
    location: "POINT(-115.1398 36.1699)",
    coordinates: { lat: 36.1699, lng: -115.1398 },
    region: "Nevada",
    operational: true
  },
  {
    name: "Texas Wind Farm Network",
    type: "wind",
    capacity: 750,
    location: "POINT(-101.8313 33.5779)",
    coordinates: { lat: 33.5779, lng: -101.8313 },
    region: "Texas",
    operational: true
  },
  {
    name: "Columbia River Hydro",
    type: "hydro",
    capacity: 300,
    location: "POINT(-121.1804 45.6387)",
    coordinates: { lat: 45.6387, lng: -121.1804 },
    region: "Oregon",
    operational: true
  },
  {
    name: "Central Valley Solar",
    type: "solar",
    capacity: 400,
    location: "POINT(-120.4579 36.7378)",
    coordinates: { lat: 36.7378, lng: -120.4579 },
    region: "California",
    operational: true
  },
  {
    name: "Great Plains Wind",
    type: "wind",
    capacity: 600,
    location: "POINT(-100.3510 41.4993)",
    coordinates: { lat: 41.4993, lng: -100.3510 },
    region: "Nebraska",
    operational: true
  }
];

// Sample demand centers data
const demandCenters: InsertDemandCenter[] = [
  {
    name: "Los Angeles Industrial District",
    type: "industrial",
    estimatedDemand: 5000,
    location: "POINT(-118.2437 34.0522)",
    coordinates: { lat: 34.0522, lng: -118.2437 },
    region: "California",
    priority: "high"
  },
  {
    name: "Houston Petrochemical Hub",
    type: "industrial",
    estimatedDemand: 8000,
    location: "POINT(-95.3698 29.7604)",
    coordinates: { lat: 29.7604, lng: -95.3698 },
    region: "Texas",
    priority: "high"
  },
  {
    name: "Chicago Transportation Hub",
    type: "transportation",
    estimatedDemand: 3000,
    location: "POINT(-87.6298 41.8781)",
    coordinates: { lat: 41.8781, lng: -87.6298 },
    region: "Illinois",
    priority: "medium"
  },
  {
    name: "Miami Port Complex",
    type: "transportation",
    estimatedDemand: 2500,
    location: "POINT(-80.1918 25.7617)",
    coordinates: { lat: 25.7617, lng: -80.1918 },
    region: "Florida",
    priority: "medium"
  },
  {
    name: "Phoenix Residential District",
    type: "residential",
    estimatedDemand: 1500,
    location: "POINT(-112.0740 33.4484)",
    coordinates: { lat: 33.4484, lng: -112.0740 },
    region: "Arizona",
    priority: "low"
  }
];

export async function seedDatabase() {
  try {
    console.log("Starting database seeding...");
    
    // Seed infrastructure assets
    console.log("Seeding infrastructure assets...");
    for (const asset of infrastructureAssets) {
      await storage.createInfrastructureAsset(asset);
    }
    
    // Seed renewable sources
    console.log("Seeding renewable sources...");
    for (const source of renewableSources) {
      await storage.createRenewableSource(source);
    }
    
    // Seed demand centers
    console.log("Seeding demand centers...");
    for (const center of demandCenters) {
      await storage.createDemandCenter(center);
    }
    
    console.log("Database seeding completed successfully!");
    
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => {
      console.log("Seeding completed");
      process.exit(0);
    })
    .catch((error) => {
      console.error("Seeding failed:", error);
      process.exit(1);
    });
}

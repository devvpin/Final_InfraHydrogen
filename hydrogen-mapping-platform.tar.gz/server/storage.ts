import { 
  infrastructureAssets, 
  renewableSources, 
  demandCenters, 
  mlRecommendations,
  users,
  type InfrastructureAsset, 
  type InsertInfrastructureAsset,
  type RenewableSource,
  type InsertRenewableSource,
  type DemandCenter,
  type InsertDemandCenter,
  type MLRecommendation,
  type InsertMLRecommendation,
  type User,
  type InsertUser
} from "@shared/schema";
import { db } from "./db";
import { eq, sql, desc, and, or } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Infrastructure methods
  getAllInfrastructureAssets(): Promise<InfrastructureAsset[]>;
  getInfrastructureAssetsByType(type: string): Promise<InfrastructureAsset[]>;
  getInfrastructureAssetsByRegion(region: string): Promise<InfrastructureAsset[]>;
  getInfrastructureAsset(id: string): Promise<InfrastructureAsset | undefined>;
  createInfrastructureAsset(asset: InsertInfrastructureAsset): Promise<InfrastructureAsset>;
  updateInfrastructureAsset(id: string, asset: Partial<InsertInfrastructureAsset>): Promise<InfrastructureAsset | undefined>;

  // Renewable sources methods
  getAllRenewableSources(): Promise<RenewableSource[]>;
  getRenewableSourcesByType(type: string): Promise<RenewableSource[]>;
  createRenewableSource(source: InsertRenewableSource): Promise<RenewableSource>;

  // Demand centers methods
  getAllDemandCenters(): Promise<DemandCenter[]>;
  getDemandCentersByType(type: string): Promise<DemandCenter[]>;
  createDemandCenter(center: InsertDemandCenter): Promise<DemandCenter>;

  // ML recommendations methods
  getAllMLRecommendations(): Promise<MLRecommendation[]>;
  getMLRecommendationsByScore(minScore: number): Promise<MLRecommendation[]>;
  createMLRecommendation(recommendation: InsertMLRecommendation): Promise<MLRecommendation>;
  deleteOldMLRecommendations(): Promise<void>;

  // Geospatial methods
  getAssetsWithinRadius(lat: number, lng: number, radiusKm: number): Promise<InfrastructureAsset[]>;
  getAnalyticsData(): Promise<{
    totalCapacity: number;
    activeProjects: number;
    averageEfficiency: number;
    totalInvestment: number;
    regionDistribution: Array<{ region: string; count: number; capacity: number }>;
    typeDistribution: Array<{ type: string; count: number; percentage: number }>;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllInfrastructureAssets(): Promise<InfrastructureAsset[]> {
    return await db.select().from(infrastructureAssets).orderBy(desc(infrastructureAssets.createdAt));
  }

  async getInfrastructureAssetsByType(type: string): Promise<InfrastructureAsset[]> {
    return await db.select().from(infrastructureAssets)
      .where(eq(infrastructureAssets.type, type))
      .orderBy(desc(infrastructureAssets.createdAt));
  }

  async getInfrastructureAssetsByRegion(region: string): Promise<InfrastructureAsset[]> {
    return await db.select().from(infrastructureAssets)
      .where(eq(infrastructureAssets.region, region))
      .orderBy(desc(infrastructureAssets.createdAt));
  }

  async getInfrastructureAsset(id: string): Promise<InfrastructureAsset | undefined> {
    const [asset] = await db.select().from(infrastructureAssets).where(eq(infrastructureAssets.id, id));
    return asset || undefined;
  }

  async createInfrastructureAsset(asset: InsertInfrastructureAsset): Promise<InfrastructureAsset> {
    const [newAsset] = await db.insert(infrastructureAssets).values({
      ...asset,
      updatedAt: sql`now()`,
    }).returning();
    return newAsset;
  }

  async updateInfrastructureAsset(id: string, asset: Partial<InsertInfrastructureAsset>): Promise<InfrastructureAsset | undefined> {
    const [updatedAsset] = await db.update(infrastructureAssets)
      .set({ ...asset, updatedAt: sql`now()` })
      .where(eq(infrastructureAssets.id, id))
      .returning();
    return updatedAsset || undefined;
  }

  async getAllRenewableSources(): Promise<RenewableSource[]> {
    return await db.select().from(renewableSources).orderBy(desc(renewableSources.createdAt));
  }

  async getRenewableSourcesByType(type: string): Promise<RenewableSource[]> {
    return await db.select().from(renewableSources)
      .where(eq(renewableSources.type, type))
      .orderBy(desc(renewableSources.createdAt));
  }

  async createRenewableSource(source: InsertRenewableSource): Promise<RenewableSource> {
    const [newSource] = await db.insert(renewableSources).values(source).returning();
    return newSource;
  }

  async getAllDemandCenters(): Promise<DemandCenter[]> {
    return await db.select().from(demandCenters).orderBy(desc(demandCenters.createdAt));
  }

  async getDemandCentersByType(type: string): Promise<DemandCenter[]> {
    return await db.select().from(demandCenters)
      .where(eq(demandCenters.type, type))
      .orderBy(desc(demandCenters.createdAt));
  }

  async createDemandCenter(center: InsertDemandCenter): Promise<DemandCenter> {
    const [newCenter] = await db.insert(demandCenters).values(center).returning();
    return newCenter;
  }

  async getAllMLRecommendations(): Promise<MLRecommendation[]> {
    return await db.select().from(mlRecommendations)
      .orderBy(desc(mlRecommendations.matchScore), desc(mlRecommendations.createdAt));
  }

  async getMLRecommendationsByScore(minScore: number): Promise<MLRecommendation[]> {
    return await db.select().from(mlRecommendations)
      .where(sql`${mlRecommendations.matchScore} >= ${minScore}`)
      .orderBy(desc(mlRecommendations.matchScore));
  }

  async createMLRecommendation(recommendation: InsertMLRecommendation): Promise<MLRecommendation> {
    const [newRecommendation] = await db.insert(mlRecommendations).values(recommendation).returning();
    return newRecommendation;
  }

  async deleteOldMLRecommendations(): Promise<void> {
    await db.delete(mlRecommendations)
      .where(sql`${mlRecommendations.createdAt} < now() - interval '24 hours'`);
  }

  async getAssetsWithinRadius(lat: number, lng: number, radiusKm: number): Promise<InfrastructureAsset[]> {
    return await db.select().from(infrastructureAssets)
      .where(sql`ST_DWithin(${infrastructureAssets.location}, ST_Point(${lng}, ${lat}), ${radiusKm * 1000})`);
  }

  async getAnalyticsData() {
    // Get total capacity and active projects
    const capacityQuery = await db.select({
      totalCapacity: sql<number>`COALESCE(SUM(${infrastructureAssets.capacity}), 0)`,
      activeProjects: sql<number>`COUNT(*)`,
      avgEfficiency: sql<number>`COALESCE(AVG(${infrastructureAssets.efficiency}), 0)`,
      totalInvestment: sql<number>`COALESCE(SUM(${infrastructureAssets.estimatedCost}), 0)`,
    }).from(infrastructureAssets);

    // Get region distribution
    const regionQuery = await db.select({
      region: infrastructureAssets.region,
      count: sql<number>`COUNT(*)`,
      capacity: sql<number>`COALESCE(SUM(${infrastructureAssets.capacity}), 0)`,
    })
    .from(infrastructureAssets)
    .groupBy(infrastructureAssets.region)
    .orderBy(sql`COUNT(*) DESC`);

    // Get type distribution
    const typeQuery = await db.select({
      type: infrastructureAssets.type,
      count: sql<number>`COUNT(*)`,
    })
    .from(infrastructureAssets)
    .groupBy(infrastructureAssets.type);

    const totalAssets = typeQuery.reduce((sum, item) => sum + item.count, 0);
    const typeDistribution = typeQuery.map(item => ({
      ...item,
      percentage: totalAssets > 0 ? (item.count / totalAssets) * 100 : 0,
    }));

    return {
      totalCapacity: capacityQuery[0]?.totalCapacity || 0,
      activeProjects: capacityQuery[0]?.activeProjects || 0,
      averageEfficiency: capacityQuery[0]?.avgEfficiency || 0,
      totalInvestment: capacityQuery[0]?.totalInvestment || 0,
      regionDistribution: regionQuery,
      typeDistribution,
    };
  }
}

export const storage = new DatabaseStorage();
